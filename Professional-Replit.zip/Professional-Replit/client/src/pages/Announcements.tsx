import { Layout } from "@/components/Layout";
import { SectionHeader } from "@/components/SectionHeader";
import { useLanguage } from "@/hooks/use-language";

export default function Announcements() {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="px-4 py-8 md:py-12">
        <SectionHeader 
          title={t("nav.news")} 
          subtitle=""
        />

        <div className="max-w-3xl mx-auto">
          {/* Empty News Section as requested */}
        </div>
      </div>
    </Layout>
  );
}
