import { Link } from "wouter";
import { Layout } from "@/components/Layout";
import { Home } from "lucide-react";

export default function NotFound() {
  return (
    <Layout>
      <div className="min-h-[80vh] flex flex-col items-center justify-center text-center px-4">
        <h1 className="text-9xl font-black text-slate-100 select-none">404</h1>
        <div className="-mt-12 relative z-10">
          <h2 className="text-2xl font-bold text-foreground mb-4">Page Not Found</h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">
            The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
          </p>
          
          <Link href="/">
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-medium shadow-lg hover:shadow-xl hover:bg-primary/90 transition-all cursor-pointer">
              <Home size={18} />
              Return Home
            </div>
          </Link>
        </div>
      </div>
    </Layout>
  );
}
