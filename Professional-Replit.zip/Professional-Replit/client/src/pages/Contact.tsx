import { Layout } from "@/components/Layout";
import { SectionHeader } from "@/components/SectionHeader";
import { Phone, Mail, Clock } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function Contact() {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="px-4 py-8 md:py-12 max-w-4xl mx-auto">
        <SectionHeader 
          title={t("contact.title")} 
          subtitle={t("contact.subtitle")}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
          <div className="bg-card p-8 rounded-3xl border border-border shadow-sm">
            <h3 className="text-2xl font-bold text-primary mb-8 border-b border-border pb-4">
              {t("contact.info")}
            </h3>
            
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-foreground">{t("contact.phone")}</h4>
                  <p className="text-muted-foreground mt-1">+212 5 22 00 00 00</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-foreground">{t("contact.email")}</h4>
                  <p className="text-muted-foreground mt-1">contact@tamayoze.edu.ma</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card p-8 rounded-3xl border border-border shadow-sm">
            <h3 className="text-2xl font-bold text-primary mb-8 border-b border-border pb-4">
              {t("contact.hours")}
            </h3>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                  <Clock size={20} />
                </div>
                <div className="space-y-2">
                  <p className="text-foreground font-medium">{t("contact.hours.mon_thu")}</p>
                  <p className="text-foreground font-medium">{t("contact.hours.fri_sat")}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
