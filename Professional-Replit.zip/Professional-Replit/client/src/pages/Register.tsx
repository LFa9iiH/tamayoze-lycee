import { Layout } from "@/components/Layout";
import { SectionHeader } from "@/components/SectionHeader";
import { FileText } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function Register() {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="px-4 py-8 md:py-12 max-w-4xl mx-auto">
        <SectionHeader 
          title={t("register.title")} 
          subtitle={t("register.subtitle")}
        />

        <div className="max-w-md mx-auto mt-12">
          <div className="bg-card p-8 rounded-3xl border border-border shadow-sm group">
            <div className="w-14 h-14 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mb-6">
              <FileText size={28} />
            </div>
            
            <div className="flex items-center gap-3">
              <h3 className="text-xl font-bold text-foreground">{t("register.step1.title")}</h3>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
