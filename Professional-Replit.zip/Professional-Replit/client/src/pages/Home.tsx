import { Link } from "wouter";
import { Layout } from "@/components/Layout";
import { ArrowRight, Camera, FolderKanban, Download } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { usePWAInstall } from "@/hooks/use-pwa-install";
import { Button } from "@/components/ui/button";

import schoolHeroImg from "@assets/501583806_10232204190782045_3454213525676919606_n_1766759102156.jpg";

export default function Home() {
  const { t, language } = useLanguage();
  const { isInstallable, install } = usePWAInstall();

  return (
    <Layout>
      <div className="px-4 py-8 md:py-16 flex flex-col items-center">
        {/* Hero Section */}
        <div className="w-full max-w-5xl text-center space-y-8">
          <div className="space-y-4">
            {isInstallable && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={install}
                className="mb-4 gap-2 rounded-full border-primary/20 bg-primary/5 hover:bg-primary/10 text-primary animate-bounce-subtle"
              >
                <Download size={16} />
                {language === "en" ? "Install App" : "تثبيت التطبيق"}
              </Button>
            )}
            <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-sm font-semibold rounded-full border border-primary/20 mb-2">
              {t("home.tagline")}
            </span>
            <h1 className="text-4xl md:text-6xl font-extrabold text-foreground leading-tight tracking-tight">
              {t("home.welcome")}
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              {t("home.description")}
            </p>
          </div>

          {/* Hero Image */}
          <div className="relative group w-full max-w-4xl mx-auto my-12 rounded-[2rem] overflow-hidden shadow-2xl shadow-primary/10 border border-border">
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent z-10" />
            <img 
              src={schoolHeroImg}
              alt="School Campus"
              className="w-full h-[400px] md:h-[500px] object-cover transition-transform duration-700 group-hover:scale-105"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center w-full max-w-lg mx-auto">
            <Link href="/gallery">
              <div className="group cursor-pointer flex items-center justify-center gap-3 px-8 py-4 bg-primary text-primary-foreground rounded-2xl font-bold shadow-lg shadow-primary/20 hover:shadow-xl transition-all duration-300 w-full sm:w-auto">
                <Camera className="w-5 h-5" />
                <span>{t("home.photos")}</span>
                <ArrowRight className="w-4 h-4 opacity-50 group-hover:translate-x-1 transition-transform rtl:rotate-180" />
              </div>
            </Link>

            <Link href="/projects">
              <div className="group cursor-pointer flex items-center justify-center gap-3 px-8 py-4 bg-card text-primary border-2 border-primary/10 rounded-2xl font-bold shadow-lg shadow-black/5 hover:border-primary/30 transition-all duration-300 w-full sm:w-auto">
                <FolderKanban className="w-5 h-5 text-secondary" />
                <span>{t("home.projects")}</span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
}
