import { Layout } from "@/components/Layout";
import { useLanguage } from "@/hooks/use-language";
import { useState } from "react";
import { X } from "lucide-react";
import img1 from "@assets/1_1766760256545.jpg";
import img2 from "@assets/2_1766760266511.jpg";
import img3 from "@assets/3_1766760276501.jpg";
import img4 from "@assets/4_1766760297224.jpg";
import img5 from "@assets/5_1766760311323.jpg";

export default function Gallery() {
  const { t } = useLanguage();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const photos = [
    { src: img1, alt: "School Photo 1" },
    { src: img2, alt: "School Photo 2" },
    { src: img3, alt: "School Photo 3" },
    { src: img4, alt: "School Photo 4" },
    { src: img5, alt: "School Photo 5" },
  ];

  return (
    <Layout>
      <div className="px-4 py-8 md:py-16">
        <div className="max-w-6xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <h1 className="text-4xl md:text-5xl font-extrabold text-foreground tracking-tight">
              {t("gallery.title")}
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto italic">
              {t("gallery.description")}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {photos.map((photo, index) => (
              <div 
                key={index} 
                className="group relative aspect-[4/3] rounded-2xl overflow-hidden shadow-lg border border-border/50 bg-muted cursor-zoom-in"
                onClick={() => setSelectedImage(photo.src)}
              >
                <img
                  src={photo.src}
                  alt={photo.alt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
            ))}
          </div>
        </div>
      </div>

      {selectedImage && (
        <div 
          className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
          onClick={() => setSelectedImage(null)}
        >
          <button 
            className="absolute top-6 right-6 text-white/70 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors"
            onClick={() => setSelectedImage(null)}
          >
            <X size={32} />
          </button>
          
          <img 
            src={selectedImage} 
            alt="Full view" 
            className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </Layout>
  );
}
