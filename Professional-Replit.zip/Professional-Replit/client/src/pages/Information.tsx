import { Layout } from "@/components/Layout";
import { useLanguage, TEAM_NAME, PROJECT_MANAGER, SCHOOL_DIRECTOR } from "@/hooks/use-language";
import { Card, CardContent } from "@/components/ui/card";
import { User, ShieldCheck, Calendar, Code } from "lucide-react";

export default function Information() {
  const { t } = useLanguage();

  const infoItems = [
    {
      label: t("info.developer"),
      value: TEAM_NAME,
      icon: Code,
    },
    {
      label: t("info.manager"),
      value: PROJECT_MANAGER,
      icon: User,
    },
    {
      label: t("info.date"),
      value: "12/12/2025",
      icon: Calendar,
    },
    {
      label: t("info.director"),
      value: SCHOOL_DIRECTOR,
      icon: ShieldCheck,
    },
  ];

  return (
    <Layout>
      <div className="px-4 py-8 md:py-16 flex flex-col items-center">
        <div className="w-full max-w-2xl space-y-8">
          <div className="text-center space-y-2">
            <h1 className="text-3xl md:text-4xl font-bold text-primary">
              {t("nav.information")}
            </h1>
          </div>

          <div className="grid gap-4">
            {infoItems.map((item, index) => (
              <Card key={index} className="border-border/50 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                    <item.icon size={24} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                      {item.label}
                    </p>
                    <p className="text-xl font-bold text-foreground">
                      {item.value}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}
