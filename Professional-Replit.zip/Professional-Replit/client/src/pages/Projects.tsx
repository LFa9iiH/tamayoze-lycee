import { Layout } from "@/components/Layout";
import { SectionHeader } from "@/components/SectionHeader";
import { useLanguage } from "@/hooks/use-language";

export default function Projects() {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="px-4 py-8 md:py-12">
        <SectionHeader 
          title={t("nav.projects")} 
          subtitle=""
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Empty Projects Section as requested */}
        </div>
      </div>
    </Layout>
  );
}
