import { createContext, useContext, useEffect, useState, ReactNode } from "react";

type Language = "en" | "ar";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: (key: string) => string;
}

// Fixed Proper Names - Constants
export const SCHOOL_NAME = "Tamayoze Technical High School";
export const TEAM_NAME = "PHANTOMES Team";
export const PROJECT_MANAGER = "Idmari Rayan";
export const SCHOOL_DIRECTOR = "El Wafi Kjamal";

const translations = {
  en: {
    "nav.home": "Home",
    "nav.news": "News",
    "nav.projects": "Projects",
    "nav.photos": "Photos",
    "nav.join": "Join",
    "nav.contact": "Contact",
    "nav.information": "Information",
    "home.welcome": `Welcome to ${SCHOOL_NAME}`,
    "home.tagline": "Excellence in Technical Education",
    "home.description": "Empowering the next generation of innovators with cutting-edge technical skills and hands-on experience.",
    "home.photos": "School Photos",
    "home.projects": "School Projects",
    "info.developer": "Developed by",
    "info.manager": "Project Manager",
    "info.date": "Publication Date",
    "info.director": "School Director",
    "contact.title": "Contact Us",
    "contact.subtitle": "Get in touch with our team",
    "contact.info": "Contact Info",
    "contact.address": "Address",
    "contact.address.val": `${SCHOOL_NAME}, Casablanca, Morocco`,
    "contact.phone": "Phone",
    "contact.email": "Email",
    "contact.hours": "Working Hours",
    "contact.hours.mon_thu": "Monday to Thursday: 09:00 – 19:00",
    "contact.hours.fri_sat": "Friday and Saturday: 09:00 – 13:00",
    "register.step1.title": "01 – Prepare Documents",
    "register.title": "How to Register",
    "register.subtitle": "Join our technical community",
    "gallery.title": "School Gallery",
    "gallery.description": `Life and activities at ${SCHOOL_NAME}`
  },
  ar: {
    "nav.home": "الرئيسية",
    "nav.news": "أخبار",
    "nav.projects": "مشاريع",
    "nav.photos": "صور",
    "nav.join": "انضمام",
    "nav.contact": "اتصل بنا",
    "nav.information": "معلومات",
    "home.welcome": `مرحباً بكم في ${SCHOOL_NAME}`,
    "home.tagline": "التميز في التعليم التقني",
    "home.description": "تمكين الجيل القادم من المبتكرين بالمهارات التقنية المتطورة والخبرة العملية.",
    "home.photos": "صور المدرسة",
    "home.projects": "مشاريع المدرسة",
    "info.developer": "تم التطوير من طرف",
    "info.manager": "مدير المشروع",
    "info.date": "تاريخ النشر",
    "info.director": "مدير المؤسسة",
    "contact.title": "اتصل بنا",
    "contact.subtitle": "تواصل مع فريقنا",
    "contact.info": "معلومات الاتصال",
    "contact.address": "العنوان",
    "contact.address.val": `${SCHOOL_NAME}، الدار البيضاء، المغرب`,
    "contact.phone": "الهاتف",
    "contact.email": "البريد الإلكتروني",
    "contact.hours": "ساعات العمل",
    "contact.hours.mon_thu": "من الاثنين إلى الخميس: 09:00 - 19:00",
    "contact.hours.fri_sat": "الجمعة والسبت: 09:00 - 13:00",
    "register.step1.title": "01 – تحضير الوثائق",
    "register.title": "كيفية التسجيل",
    "register.subtitle": "انضم إلى مجتمعنا التقني",
    "gallery.title": "معرض الصور",
    "gallery.description": `الحياة والأنشطة في ${SCHOOL_NAME}`
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem("language");
    return (saved === "en" || saved === "ar") ? saved : "en";
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("language", lang);
  };

  const toggleLanguage = () => {
    setLanguage(language === "en" ? "ar" : "en");
  };

  const t = (key: string) => {
    return (translations[language] as any)[key] || key;
  };

  useEffect(() => {
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = language;
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
