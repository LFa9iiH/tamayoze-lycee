import { Link, useLocation } from "wouter";
import { Home, Bell, UserPlus, Phone, Camera, Briefcase, Sun, Moon, Languages } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/hooks/use-theme";
import { useLanguage } from "@/hooks/use-language";

export function Navigation() {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { language, toggleLanguage, t } = useLanguage();

  const links = [
    { href: "/", label: t("nav.home"), icon: Home },
    { href: "/announcements", label: t("nav.news"), icon: Bell },
    { href: "/projects", label: t("nav.projects"), icon: Briefcase },
    { href: "/gallery", label: t("nav.photos"), icon: Camera },
    { href: "/register", label: t("nav.join"), icon: UserPlus },
    { href: "/contact", label: t("nav.contact"), icon: Phone },
    { href: "/information", label: t("nav.information"), icon: Bell },
  ];

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:block fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-8 ml-auto border-r pr-6 border-border">
            {links.map((link) => (
              <Link key={link.href} href={link.href}>
                <div className={cn(
                  "cursor-pointer text-sm font-medium transition-colors hover:text-primary",
                  location === link.href ? "text-primary font-bold" : "text-muted-foreground"
                )}>
                  {link.label}
                </div>
              </Link>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={toggleLanguage} className="gap-2">
              <Languages size={18} />
              <span className="font-bold">{language === "en" ? "AR" : "EN"}</span>
            </Button>
            <Button variant="ghost" size="icon" onClick={toggleTheme} className="rounded-full">
              {theme === "light" ? <Moon size={20} /> : <Sun size={20} />}
            </Button>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 w-full bg-background border-t border-border z-50 pb-safe">
        <div className="flex items-center justify-around py-3">
          {links.map((link) => {
            const isActive = location === link.href;
            return (
              <Link key={link.href} href={link.href}>
                <div className={cn(
                  "flex flex-col items-center gap-1 cursor-pointer w-14 transition-all duration-200",
                  isActive ? "text-primary scale-110" : "text-muted-foreground hover:text-primary/70"
                )}>
                  <link.icon 
                    size={18} 
                    strokeWidth={isActive ? 2.5 : 2}
                    className={isActive ? "text-primary" : ""}
                  />
                  <span className="text-[9px] font-medium">{link.label}</span>
                </div>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Mobile Utility Toggles */}
      <div className="md:hidden fixed top-4 right-4 z-[60] flex items-center gap-2">
        <Button variant="secondary" size="sm" onClick={toggleLanguage} className="rounded-full shadow-lg bg-background/80 backdrop-blur-sm">
          {language === "en" ? "AR" : "EN"}
        </Button>
        <Button variant="secondary" size="icon" onClick={toggleTheme} className="rounded-full shadow-lg bg-background/80 backdrop-blur-sm">
          {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
        </Button>
      </div>
      
      {/* Spacer for desktop header */}
      <div className="hidden md:block h-20" />
    </>
  );
}
