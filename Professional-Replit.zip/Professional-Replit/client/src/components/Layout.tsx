import { ReactNode } from "react";
import { Navigation } from "./Navigation";
import { motion } from "framer-motion";
import { useLanguage } from "@/hooks/use-language";

export function Layout({ children }: { children: ReactNode }) {
  const { language } = useLanguage();

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0" dir={language === "ar" ? "rtl" : "ltr"}>
      <Navigation />
      <motion.main
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.3 }}
        className="max-w-7xl mx-auto w-full"
      >
        {children}
      </motion.main>
    </div>
  );
}
