interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  className?: string;
}

export function SectionHeader({ title, subtitle, className }: SectionHeaderProps) {
  return (
    <div className={`text-center mb-10 ${className}`}>
      <h2 className="text-3xl md:text-4xl font-bold text-primary mb-3 drop-shadow-sm">
        {title}
      </h2>
      {subtitle && (
        <div className="w-16 h-1 bg-secondary mx-auto rounded-full mb-4" />
      )}
      {subtitle && (
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          {subtitle}
        </p>
      )}
    </div>
  );
}
