import { db } from "./db";
import {
  announcements, projects, gallery,
  type Announcement,
  type Project,
  type GalleryItem
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getAnnouncements(): Promise<Announcement[]>;
  getProjects(): Promise<Project[]>;
  getGalleryItems(): Promise<GalleryItem[]>;
  getAnnouncement(id: number): Promise<Announcement | undefined>;
  getProject(id: number): Promise<Project | undefined>;
  seedData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getAnnouncements(): Promise<Announcement[]> {
    return await db.select().from(announcements).orderBy(desc(announcements.id));
  }
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }
  async getGalleryItems(): Promise<GalleryItem[]> {
    return await db.select().from(gallery);
  }
  async getAnnouncement(id: number): Promise<Announcement | undefined> {
    const [item] = await db.select().from(announcements).where(eq(announcements.id, id));
    return item;
  }
  async getProject(id: number): Promise<Project | undefined> {
    const [item] = await db.select().from(projects).where(eq(projects.id, id));
    return item;
  }
  async seedData(): Promise<void> {
    const existingAnnouncements = await this.getAnnouncements();
    if (existingAnnouncements.length === 0) {
      await db.insert(announcements).values([
        {
          title: "Registration Open for 2024-2025",
          date: "August 15, 2024",
          content: "We are now accepting applications for the upcoming school year. Visit the registration page for details."
        },
        {
          title: "School Science Fair Winners",
          date: "May 20, 2024",
          content: "Congratulations to our robotics team for taking first place in the regional competition!"
        },
        {
          title: "Parent-Teacher Meeting",
          date: "April 10, 2024",
          content: "Join us this Saturday for our semester parent-teacher conference."
        }
      ]);
    }
    const existingProjects = await this.getProjects();
    if (existingProjects.length === 0) {
      await db.insert(projects).values([
        {
          title: "Solar Powered Charging Station",
          description: "A student-built charging station powered entirely by solar panels installed on the school roof.",
          imageUrl: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&auto=format&fit=crop"
        },
        {
          title: "Smart Irrigation System",
          description: "An IoT project that optimizes water usage for the school gardens using moisture sensors.",
          imageUrl: "https://images.unsplash.com/photo-1550989460-0adf9ea622e2?w=800&auto=format&fit=crop"
        },
        {
          title: "Automated Library Catalog",
          description: "A digital cataloging system developed by the CS department for the school library.",
          imageUrl: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=800&auto=format&fit=crop"
        }
      ]);
    }
    const existingGallery = await this.getGalleryItems();
    if (existingGallery.length === 0) {
      await db.insert(gallery).values([
        { imageUrl: "https://images.unsplash.com/photo-1562774053-701939374585?w=800&auto=format&fit=crop", caption: "Main Campus Building" },
        { imageUrl: "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&auto=format&fit=crop", caption: "Computer Lab" },
        { imageUrl: "https://images.unsplash.com/photo-1564981797816-1043664bf78d?w=800&auto=format&fit=crop", caption: "Chemistry Workshop" },
        { imageUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&auto=format&fit=crop", caption: "Student Study Area" }
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
