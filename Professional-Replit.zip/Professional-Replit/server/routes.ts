import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Seed data on startup
  await storage.seedData();

  app.get(api.announcements.list.path, async (req, res) => {
    const data = await storage.getAnnouncements();
    res.json(data);
  });

  app.get(api.announcements.get.path, async (req, res) => {
    const item = await storage.getAnnouncement(Number(req.params.id));
    if (!item) return res.status(404).json({ message: "Not found" });
    res.json(item);
  });

  app.get(api.projects.list.path, async (req, res) => {
    const data = await storage.getProjects();
    res.json(data);
  });

  app.get(api.projects.get.path, async (req, res) => {
    const item = await storage.getProject(Number(req.params.id));
    if (!item) return res.status(404).json({ message: "Not found" });
    res.json(item);
  });

  app.get(api.gallery.list.path, async (req, res) => {
    const data = await storage.getGalleryItems();
    res.json(data);
  });

  return httpServer;
}
